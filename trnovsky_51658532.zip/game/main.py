from game import *

Game().play()
